# Characterizing by Word Frequencies and Computing Summary Statistics
import random
import string

# Cleaning the data
def process_file(filename, skip_header):
    """Makes a histogram that contains the words from a file.
    filename: string
    skip_header: boolean, whether to skip the Gutenberg header
    returns: map from each word to the number of times it appears.
    """
    hist = {}
    fp = open(filename, encoding="utf8")

    if skip_header:
        skip_gutenberg_header(fp)

    strippables = string.punctuation + string.whitespace

    for line in fp:
        if line.startswith("*** END OF THIS PROJECT"):
            break

        line = line.replace("-", " ")
        # line = line.replace(
        #     chr(8212), ' '
        # )  # Unicode 8212 is the HTML decimal entity for em dash

        for word in line.split():
            # remove punctuation and convert to lowercase
            word = word.strip(strippables)
            word = word.lower()

            # update the histogram
            hist[word] = hist.get(word, 0) + 1

    return hist


def skip_gutenberg_header(fp):
    """Reads from fp until it finds the line that ends the header.
    fp: open file object
    """
    for line in fp:
        if line.startswith("*** START OF THIS PROJECT"):
            break


# Characterizing by Word Frequencies
def total_words(hist):
    """Returns the total of the frequencies in a histogram."""
    return sum(hist.values())


def different_words(hist):
    """Returns the number of different words in a histogram."""
    return len(hist)


# Computing Summary Statistics
def most_common(hist, excluding_stopwords=True):
    """Makes a list of word-freq pairs(tuples) in descending order of frequency.
    hist: map from word to frequency
    excluding_stopwords: a boolean value. If it is True, do not include any stopwords in the list.
    returns: list of (frequency, word) pairs
    """
    t = []

    stopwords = process_file("data/stopwords.txt", False)

    stopwords = list(stopwords.keys())
    # print(stopwords)

    for word, freq in hist.items():
        if excluding_stopwords:
            if word in stopwords:
                continue
        t.append((freq, word))
    t.sort(reverse=True)
    return t


def print_most_common(hist, num=10, excluding_stopwords=False):
    """Prints the 10 most commons words in a histgram and their frequencies.
    hist: histogram (map from word to frequency)
    num: number of words to print
    """
    t = most_common(hist, excluding_stopwords=True)
    print("The most common words are:")
    for freq, word in t[:num]:
        print(word, "\t", freq)


def main():
    # The Adventures of Tom Sawyer
    adventures = process_file("data/The Adventures of Tom Sawyer.txt", skip_header=True)
    print("Title: The Adventures of Tom Sawyer")
    print("Total number of words:", total_words(adventures))
    print("Number of different words:", different_words(adventures))

    t1 = most_common(adventures, False)

    print("The most common words are:")
    for freq, word in t1[0:10]:
        print(word, "\t", freq)
    print_most_common(adventures, 10)

    words = process_file("data\words.txt", skip_header=False)

    print("-" * 50)
    # Adventures of Huckleberry Finn
    theadventures = process_file(
        "data/Adventures of Huckleberry Finn.txt", skip_header=True
    )
    print("Title: Adventures of Huckleberry Finn")
    print("Total number of words:", total_words(theadventures))
    print("Number of different words:", different_words(theadventures))

    t2 = most_common(theadventures, False)

    print("The most common words are:")
    for freq, word in t2[0:10]:
        print(word, "\t", freq)
    print_most_common(adventures, 10)

    words = process_file("data\words.txt", skip_header=False)


if __name__ == "__main__":
    main()
