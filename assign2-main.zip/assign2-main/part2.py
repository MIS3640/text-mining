# Text Analaysis - Sentiment Analysis; Text Similarity; Text Clustering 

import string
import urllib.request
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
# nltk.download('vader_lexicon')
import numpy as np                  #pip install numpy
from sklearn.manifold import MDS    #pip install scikit-learn
import matplotlib.pyplot as plt     #pip install matplotlib

# Download the books 
def download_url(url):
    """
    Download the books from Project Gutenberg
    """
    response = urllib.request.urlopen(url)
    data = response.read()  # a `bytes` object
    text = data.decode('utf-8')
    return text

# Cleaning the data
def process_url(text, skip_header=True):
    """
    Process a string and map each word to its frequency
    """
    hist = {}

    strippables = string.punctuation + string.whitespace + "“" + "”"
    
    # skip = True
    for line in text.split('\n'):
        if skip_header:
            if line.startswith('*** START OF THIS PROJECT'):
                skip = False
                continue
        if line.startswith('*** END OF THIS PROJECT'):
            break

        line = line.replace('-', ' ')
        # line = line.replace(chr(8212), ' ')  # Unicode 8212 is the HTML decimal entity for em dash

        for word in line.split():
            # remove punctuation and convert to lowercase
            word = word.strip(strippables)
            word = word.lower()
            # update the histogram 
            hist[word] = hist.get(word, 0) + 1

    return hist


# Sentiment Analysis
def sentiment_analysis(text):
    """
    Return negative, neutral, positive, and compound (sentiment)
    """
    score = SentimentIntensityAnalyzer().polarity_scores(text)
    return(score)

# Text Similarity 
def text_similarity(d1, d2):
    """
    Use the cosine to calculate similarity between d1 and d2 (2 books) and return 0 or 1
    """
    t1 = []
    t2 = []
    s1 = {word for word in d1.keys()}
    s2 = {word for word in d2.keys()}
    # create a set that containing words in both texts/books
    bothword = s1.union(s2)
    for word in bothword:
        if word in s1:
            t1.append(d1[word])
        else:
            t1.append(0)
        if word in s2:
            t2.append(d2[word])
        else:
            t2.append(0)
    c = 0
    sum1 = 0
    sum2 = 0
    # cosine formula
    for i in range(len(bothword)):
        c += t1[i]*t2[i]
        sum1 += t1[i]**2
        sum2 += t2[i]**2

    cosine = c/(sum1*sum2)**0.5

    return cosine

# Text Clustering 
def similarity(*b):
    """
    use text_similarity to returns a matrix of similarities
    """
    sim_array = []
    for i in range(len(b)):
        sim_row = []
        for j in range(len(b)):
            sim = text_similarity(b[i], b[j])
            sim_row.append(sim)
        sim_array.append(sim_row)
    return sim_array

def t_clustering(text1, text2, text3, text4): 
    """
    return a plot that show similarity relationship 
    """
    sim_matrix = similarity(text1, text2, text3, text4)
    S = np.asarray(sim_matrix)
    # dissimilarity is 1 minus similarity
    dissimilarities = 1 - S
    # compute the embedding
    coord = MDS(dissimilarity='precomputed').fit_transform(dissimilarities)
    plt.scatter(coord[:, 0], coord[:, 1])
    # Label the points
    for i in range(coord.shape[0]):
        plt.annotate(str(i), (coord[i, :]))
    plt.show()


def main():
    # Url of the four books 
    # The Adventures of Tom Sawyer
    adventuresurl = 'http://www.gutenberg.org/files/74/74-0.txt'
    adventuretxt = download_url(adventuresurl)
    adventures = process_url(adventuresurl)

    # Adventures of Huckleberry Finn
    theadvurl = 'http://www.gutenberg.org/ebooks/76'
    theadvtxt = download_url(theadvurl)
    theadv = process_url(theadvurl)


    # Oliver Twist
    oliverurl = 'http://www.gutenberg.org/cache/epub/730/pg730.txt'
    olivertxt = download_url(oliverurl)
    oliver = process_url(olivertxt)

    # Great Expectations
    greaturl = 'http://www.gutenberg.org/files/1400/1400-0.txt'
    greattxt = download_url(greaturl)
    great = process_url(greattxt)

    # # Sentiment Analysis
    # print(f"The Adventures of Tom Sawyer {sentiment_analysis(adventuretxt)}")
    # print(f"Adventures of Huckleberry Finn {sentiment_analysis(theadvtxt)}")

    # Text Similarity 
    # print(text_similarity(adventures , theadv))
    # print(text_similarity(adventures, oliver))
    # print(text_similarity(adventures , great))
    # print(text_similarity(theadv,oliver))
    # print(text_similarity(theadv,great))
    # print(text_similarity(oliver , great))

    
    # Text Clustering 
    t_clustering(adventures,theadv,oliver,great)


if __name__ == '__main__':
    main()