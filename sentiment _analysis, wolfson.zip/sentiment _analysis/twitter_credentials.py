# this file contains my  personal twitter credentials in variable form 

token = '708013197060657152-MOq9K2WaueJJRuxPWwhsJbVeCDccr42'
token_secret = 'ACHgS2VAI5udSOSkxYjdBbj3YIgXObEWQHPs0FCSVDUFo'
consumer_key  = 'bhMOINHjn7hJrSuw207fISCuZ'
consumer_secret = 'dNPYY23HgRyCvzsOvEFkQ1XYJdemSczBAD7wFx4XOVC3vDlqPY'

